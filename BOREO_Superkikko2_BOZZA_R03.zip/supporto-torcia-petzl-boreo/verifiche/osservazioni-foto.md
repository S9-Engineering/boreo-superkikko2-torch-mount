# Osservazioni sulle foto dell'utente

Data di ricezione: **15 ottobre 2026**. Originali in `sorgenti/riferimenti/foto-utente/`.

## Riscontri visivi

| Foto | Osservazioni | Limiti |
| --- | --- | --- |
| [1](../sorgenti/riferimenti/foto-utente/Foto-1.jpg) | Etichetta Petzl BOREO, M/L, 53–61 cm, 330 g; schiuma interna, girotesta e fettucce visibili. Presente anche un elemento metallico interno nella parte superiore dell'immagine. | Non si legge codice prodotto/data; funzione e collegamento dell'elemento metallico non dimostrati. |
| [2](../sorgenti/riferimenti/foto-utente/Foto-2.jpg) | Due aperture oblique nella zona anteriore interna e una fascia/fascetta nera vicino al loro margine inferiore; imbottitura frontale e sommitale visibili. | Nessuna scala; profondità, percorso completo e spazio libero per un inserto non determinabili. |
| [3](../sorgenti/riferimenti/foto-utente/Foto-3.jpg) | Vista laterale del montaggio: torcia alettata, staffa metallica con vite laterale; apertura del casco e fascetta nera. | Marca/modello e filetto non confermati; non si deduce il percorso completo del fissaggio. |
| [4](../sorgenti/riferimenti/foto-utente/Foto-4.jpg) | Vista esterna frontale/superiore: staffa metallica a U intorno alla torcia, piastra con asola e fascetta nera trasversale; si vedono due piccoli fissaggi vicini alla parte centrale. Sopra è presente un accessorio separato con scritta OSMO. | Numero/funzione di tutti i fissaggi e loro corrispondenza con le parti interne non dimostrati. La scritta OSMO identifica un altro accessorio e non va usata per identificare la torcia. |

## Scelta confermata e interpretazione di progetto

La scelta iniziale di conservare la staffa è stata **sostituita dall'ultima istruzione dell'utente**: «Anche la staffa u, avviterò direttamente ai lati della torcia quindi prevedi una U che entra direttamente nel casco e mette due fori ai lati».

Il concetto R02 sostituisce piastra asolata e staffa a U con un unico corpo stampato: ponte interno, bracci passanti e orecchie con due fori laterali coassiali. L'interfaccia attiva è quella dei due punti laterali di inclinazione della Superkikko2, visibili nella foto 3. I due fissaggi centrali della foto 4 non sono usati.

Il passaggio attraverso le aperture anteriori è il percorso di lavoro. Le foto non dimostrano la montabilità di una U rigida monopezzo: servono rilievo e dima d'inserimento.

## Dati mancanti

- Quote delle facce laterali della torcia, asse di inclinazione e ferramenta per i fori della nuova U.
- Rilievo in millimetri delle aperture e della zona di appoggio, compresa la profondità e la forma locale.
- Sequenza d'inserimento della U monopezzo attraverso entrambe le aperture senza forzare i componenti del casco.
- Massa del gruppo da sostenere e spazio necessario per regolarne l'inclinazione.
- Verifica delle interferenze con schiume, imbottiture, cinghie e girotesta.

Non è stata ricavata alcuna misura da pixel, dita o dimensioni presunte della ferramenta. Non è stato diagnosticato lo stato di conservazione del casco dalle foto e non è stata verificata la compatibilità protettiva di alcun inserto.
