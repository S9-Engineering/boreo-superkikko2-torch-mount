# Supporto torcia per Petzl BOREO

## Stato al 15 ottobre 2026

**Bozza R03 di forma, non funzionale.** Su richiesta dell'utente è stata modellata una prima U «a occhio», con quote nominali modificabili e dichiarate **ASSUNTE**. Sono disponibili CAD ed esportazioni verificate; adattamento al casco e alla torcia, montabilità e comportamento in uso non sono verificati. Il progetto non è pronto per la stampa.

La [bozza R03](bozza-R03/README.md) sviluppa il concetto R02 a U diretta. Vedi l'[anteprima della geometria](bozza-R03/anteprime/BOZZA_R03_anteprima.png). I file della bozza sono raccolti in [bozza-R03/stampa/](bozza-R03/stampa/): STL, STEP e **3MF soltanto geometrico** in millimetri, senza profili o slicing; GLB per visualizzazione in metri secondo glTF. È presente un solo corpo.

La successiva [valutazione di peso e calore](verifiche/valutazione-termica-preliminare.md) usa i 130 g dichiarati per il corpo lampada e scenari di carico espliciti. La temperatura presso gli attacchi non è pubblicata nelle fonti consultate: materiale e spessori funzionali restano da definire anche per la tenuta a caldo. Sono disponibili [revisione meccanica della R03](bozza-R03/verifiche/revisione-meccanica-r03.md) e [dati dei materiali](verifiche/fonti-materiali-preliminari.md). Nessuna modifica geometrica deriva ancora da questi confronti.

## Richiesta attuale — U diretta R02, bozza di forma R03

L'utente ha modificato la scelta iniziale e richiesto di **sostituire sia la piastra asolata sia la staffa metallica a U** della **Kikko Lamp Superkikko2**. Il collegamento richiesto è diretto ai due punti laterali della torcia. La precedente proposta con staffa a U conservata e traversino separato è **superata**.

Il concetto attuale è **un unico corpo a U**: ponte curvo all'interno del casco, due bracci che attraversano le aperture anteriori già esistenti e due orecchie esterne ai lati della lampada. Ogni orecchia contiene un foro passante; i due fori sono **coassiali lungo la direzione sinistra–destra**, in corrispondenza dei perni laterali d'inclinazione della torcia. I due fissaggi centrali della vecchia piastra non sono usati.

**Vincoli ribaditi dall'utente:** elastici esclusi per usura, sporco e possibilità d'impiglio; nessun nuovo foro nel casco; fissaggio compatto e permanente nell'uso ordinario, smontabile per manutenzione. La ricerca di accessori esterni non cambia questa scelta. Non proporre nuovamente fasce elastiche come sviluppo del progetto.

La bozza R03 conserva ponte arcuato, due bracci integrali raccordati e due orecchie laterali con fori coassiali. Non contiene traversini esterni, staffa metallica o elastici. Prima di ricavarne un prototipo funzionale restano da verificare accesso, posizione dei passaggi, curva locale, interfaccia dei perni e libertà d'inclinazione. Le quote funzionali reali non sono state ancora fornite.

I bracci saranno raccordati al ponte con transizioni arrotondate e dovranno adattare la posizione dei passaggi alla larghezza dell'interfaccia laterale della lampada. La torcia si inserisce tra le orecchie dopo il posizionamento del supporto nel casco. L'inseribilità della U monopezzo non è ancora verificata: occorre una dima del passaggio, senza forzare calotta o schiuma. Non si richiede al pezzo di flettersi per entrare o per accogliere la lampada.

### Curvatura e ingombro interno

L'utente ha precisato che la fascia interna deve seguire la curva del casco ed essere **molto sottile**, e che ha difficoltà a rilevarne le quote. Questo è un requisito qualitativo: non è stato ancora dichiarato uno spessore massimo né se il vincolo riguardi anche i bracci esterni.

Il ponte R03 è già curvo: raggio nominale di centrolinea **110 mm**, corda **120 mm**, spessore radiale **1,2 mm** e altezza **12 mm**. Sono ipotesi di forma, non misure del casco. Anche la luce fra le orecchie (**68 mm**), il loro spessore (**4 mm**) e i fori lisci (**Ø 4,5 mm**, senza filettatura attribuita alla Superkikko2) sono assunti. Tutti i valori sono modificabili in [parametri_assunti.json](bozza-R03/sorgenti/parametri_assunti.json).

Per ricostruire la linea d'appoggio reale si può usare un profilo di cartoncino adattato alla sezione interna e fotografato in piano con un riferimento metrico, oppure confrontare piccole dime di curvatura. Una striscia flessibile semplicemente piegata e poi raddrizzata non conserva l'informazione di curvatura. L'adattamento della fascia alla superficie tridimensionale del casco va verificato con una dima locale.

La proposta conserva un unico pezzo, con fascia interna sottile e raccordi progressivi verso bracci e zone dei fori più consistenti all'esterno. La fascia interna resta nel percorso del carico: i rinforzi esterni da soli non dimostrano che possa essere arbitrariamente sottile. Lo spessore finale dipende da spazio libero, materiale, orientamento di stampa, carico e ferramenta. Non è stata attribuita a una fascia FDM sottile la rigidità della precedente lamina metallica. Nessuna quota di spessore o compatibilità con testa, girotesta e schiuma è ancora verificata.

La [descrizione del produttore della Superkikko2](https://www.kikkolamp.com/superkikko2) conferma che la staffa originale è a U in acciaio inox e permette fissaggio e inclinazione. La pagina non fornisce un disegno quotato dell'attacco. Nel concetto R02 queste funzioni passano alla U stampata: rigidità, serraggio e comportamento termico vanno verificati per il nuovo materiale. Occorre rilevare diametro, filetto, spallamenti, rondelle, lunghezza sotto testa e impegno disponibile dei fissaggi laterali. Le viti originali saranno riutilizzate soltanto se compatibili con il nuovo spessore. Dissipatore, cavo e inclinazione devono restare liberi. Non ottenere stabilità schiacciando la schiuma del casco con il serraggio.

Il casco indicato è il BOREO più recente. Le foto dell'utente confermano la taglia **M/L, 53–61 cm** e la massa nominale **330 g** riportate sull'etichetta. Codice prodotto e data di fabbricazione non sono leggibili nelle immagini ricevute; la generazione esatta non viene attribuita dalla sola somiglianza visiva.

## Rilievo fotografico dell'esemplare

Sono conservate quattro [foto originali dell'utente](sorgenti/riferimenti/foto-utente/), ricevute il 15 ottobre 2026. Le osservazioni sono raccolte in [verifiche/osservazioni-foto.md](verifiche/osservazioni-foto.md).

Le immagini mostrano le aperture anteriori viste dall'interno, una fascetta nera e la staffa metallica a U attuale. Il nuovo pezzo sostituisce piastra e staffa e raggiunge direttamente i due attacchi laterali della torcia. Il percorso completo della fascetta non è documentato dalle immagini.

Le foto non contengono un riferimento metrico adatto al rilievo. Non sono state ricavate quote da dita, viti, scritte o proporzioni del casco.

## Esito della ricerca

La [scheda Petzl del BOREO attuale](https://www.petzl.com/it/it/sport/prodotti/caschi-arrampicata-e-alpinismo-uomo/boreo/BOREO_SPO_a2m68000000PBAgAAO.html) riporta la famiglia A042VA, taglie S/M (girotesta 48–58 cm, 300 g) e M/L (53–61 cm, 330 g), calotta ABS e componenti assorbenti EPP/EPS. Il girotesta non permette di ricavare curvatura, spazio interno o quote delle aperture. Nelle risorse ufficiali consultate non è stato trovato un CAD del casco o un disegno quotato dell'interno.

Petzl limita il [vecchio attacco da avvitare E55940](https://www.petzl.com/IT/it/Sport/Lampade-frontali/Attacco-per-casco-da-speleologia) ai BOREO precedenti al 2023. Questo attacco non dimostra la compatibilità con il casco attuale.

Esiste anche il [DUO HELMET ADAPT E103BB00](https://www.petzl.com/us/en/sport/products/accessories-for-headlamps/duo-helmet-adapt/DUO-HELMET-ADAPT_SPO_a2m68000000XZeqAAG.html), rimovibile, con piastre esterne ed elastici, destinato alle DUO RL/S. Petzl pubblica collegamenti a STL anteriore e posteriore: sono geometrie dell'accessorio, non del casco. La relativa nota indica SLS e PA12 per il frontale; non è una convalida della riproduzione in FDM con PLA, PETG Pro o TPU.

Le fonti e i limiti sono raccolti in [verifiche/ricerca-fonti.md](verifiche/ricerca-fonti.md).

La ricerca successiva dedicata al casco normale e ai fissaggi esterni è in [verifiche/supporti-boreo-normale.md](verifiche/supporti-boreo-normale.md): include DUO HELMET ADAPT, staffa/elastici Kikko originali e confronto con la piastra già fotografata. La ricerca non modifica automaticamente il concetto R02 scelto dall'utente.

## Dati necessari per rendere funzionale la bozza

1. Taglia M/L confermata dall'etichetta; restano da rilevare codice/data e quote locali con riferimento metrico nella zona interessata.
2. Modello Superkikko2 confermato; rilevare larghezza fra le facce laterali d'appoggio, posizione dell'asse d'inclinazione, ingombro di rotazione e massa da sostenere.
3. Percorso delle due alette e quote locali di ciascun passaggio: luce utile, interasse e profondità, senza forzare o modificare il casco.
4. Spazio disponibile per l'inserto, posizione delle schiume, delle cinghie e del girotesta. Non ricavare questo spazio comprimendo le schiume o riducendo la corretta vestibilità.
5. Diametro/filetto, lunghezza sotto testa e impegno utile dei fissaggi laterali, con rondelle/spallamenti. Distinguere larghezza della lampada, gioco per lato e gioco totale tra le orecchie. I due fori appartengono allo stesso asse.

La scheda [sorgenti/misure-da-rilevare.json](sorgenti/misure-da-rilevare.json) conserva le **misure reali mancanti come `null`**. È separata dai parametri **ASSUNTI** della bozza R03: i valori nominali del CAD non compilano e non sostituiscono il rilievo.

Per il rilievo usare la [scheda pratica R02 con le quote A–D](sorgenti/scheda-rilievo.md), riferita ai punti laterali della foto 3 e alle aperture del casco. Le vecchie quote sui due fissaggi centrali non sono più l'interfaccia di progetto.

## Vincoli di progetto

La nota del BOREO avverte che modificare o rimuovere componenti originali fuori dalle indicazioni del fabbricante danneggia il casco e sconsiglia fissaggi non raccomandati. Un inserto interno su misura richiede quindi anche una verifica della soluzione con Petzl: la sola assenza di fori nuovi non ne dimostra la compatibilità protettiva.

La R03 serve a discutere la forma. Una successiva dima locale potrà verificare accoppiamenti e ingombri a casco non indossato; non sarà un accessorio convalidato per uso in grotta. Un CAD completo del casco non è indispensabile se si dispone di un rilievo affidabile della zona di appoggio e dei passaggi.

Materiale, spessori funzionali, giochi, orientamento e ferramenta saranno scelti dopo la definizione dei contatti e dell'interfaccia della torcia. Non sono ancora impostati profili o parametri di stampa; tempi e consumi non sono stimati.

## Verifiche

| Controllo | Esito |
| --- | --- |
| Ricerca scheda e manuale del BOREO attuale | Eseguita; fonti collegate nel dossier |
| Identificazione dell'esemplare e taglia | Taglia M/L, girotesta e massa nominale letti nella foto 1; codice/data non leggibili |
| Rilievo interno e interfaccia torcia | Quattro foto archiviate; interfaccia laterale scelta, quote reali mancanti |
| Compatibilità dell'inserto con le indicazioni Petzl | Non dimostrata |
| CAD ed esportazioni R03 | Un corpo a U; STL, STEP, GLB e 3MF geometrico disponibili |
| Verifica indipendente dei file esportati | **25 controlli superati**: file riaperti, geometria coerente e quote nominali controllate; [report](bozza-R03/verifiche/verifica_indipendente.json) |
| Adattamento a casco/torcia, inseribilità e interferenze reali | Non verificati; le quote del CAD sono assunte |
| Slicing con profilo Centauri Carbon 2 Combo | Non eseguito |
| Prova fisica e verifica funzionale | Non eseguite |

Le esportazioni e le anteprime attuali sono nella sottocartella **bozza-R03**. I controlli geometrici non dimostrano compatibilità, resistenza o buon esito della stampa. L'avvio della stampa non è incluso in questa fase.
